// Toggles bookmarks through admin-ajax so the page does not reload.
const bookmarkSettings = window.dlcBookmarks;

async function toggleBookmark(button) {
  const formData = new FormData();
  formData.append('action', 'dlc_toggle_bookmark');
  formData.append('nonce', bookmarkSettings.nonce);
  formData.append('postId', button.dataset.postId);

  // Disabled while the request runs so a double click cannot toggle twice.
  button.disabled = true;

  try {
    const response = await fetch(bookmarkSettings.ajaxUrl, {
      method: 'POST',
      body: formData,
      credentials: 'same-origin'
    });
    const result = await response.json();

    if (result.success) {
      button.setAttribute('aria-pressed', String(result.data.bookmarked));
    }
  } catch (error) {
    console.error('Bookmark request failed', error);
  } finally {
    button.disabled = false;
  }
}

document.addEventListener('click', (event) => {
  const button = event.target.closest('.dlc-bookmark-button');

  if (button && bookmarkSettings) {
    toggleBookmark(button);
  }
});
