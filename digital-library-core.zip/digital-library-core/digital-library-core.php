<?php
/**
 * Plugin Name: Digital Library Core
 * Description: Ebook management, research repository, search filters, user accounts and access control for the digital library.
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
  exit;
}

define('DLC_VERSION', '1.0.0');
define('DLC_PATH', plugin_dir_path(__FILE__));
define('DLC_URL', plugin_dir_url(__FILE__));

require_once DLC_PATH . 'includes/post-types.php';
require_once DLC_PATH . 'includes/roles.php';
require_once DLC_PATH . 'includes/uploads.php';
require_once DLC_PATH . 'includes/meta-fields.php';
require_once DLC_PATH . 'includes/access-control.php';
require_once DLC_PATH . 'includes/bookmarks.php';
require_once DLC_PATH . 'includes/search.php';
require_once DLC_PATH . 'includes/user-pages.php';
require_once DLC_PATH . 'includes/submissions.php';
require_once DLC_PATH . 'includes/assets.php';

// Post types and roles must exist before rewrite rules are flushed.
function dlc_activate() {
  dlc_register_post_types();
  dlc_register_taxonomies();
  dlc_add_roles();
  dlc_create_default_pages();
  dlc_protect_upload_dir();
  flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'dlc_activate');

function dlc_deactivate() {
  flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'dlc_deactivate');
