<?php
/**
 * Access control: gated downloads and keeping the admin area for staff only.
 */

if (!defined('ABSPATH')) {
  exit;
}

function dlc_get_download_url($post_id) {
  return add_query_arg('dlc-download', absint($post_id), home_url('/'));
}

// Files are streamed through PHP so the capability check cannot be skipped.
function dlc_handle_download() {
  if (!isset($_GET['dlc-download'])) {
    return;
  }

  $post_id = absint($_GET['dlc-download']);
  if (!dlc_is_published_resource($post_id)) {
    wp_die('This resource could not be found.', 'Not found', array('response' => 404));
  }

  if (!is_user_logged_in()) {
    $login_url = add_query_arg('redirect_to', rawurlencode(get_permalink($post_id)), dlc_get_page_url('login'));
    wp_safe_redirect($login_url);
    exit;
  }

  if (!current_user_can('dlc_use_library')) {
    wp_die('Your account is not allowed to download files.', 'Not allowed', array('response' => 403));
  }

  $file_id = absint(get_post_meta($post_id, 'dlc_file_id', true));
  $path = $file_id ? get_attached_file($file_id) : '';
  if (!$path || !is_readable($path)) {
    wp_die('The file for this resource is not available.', 'Not found', array('response' => 404));
  }

  $download_count = absint(get_post_meta($post_id, 'dlc_download_count', true));
  update_post_meta($post_id, 'dlc_download_count', $download_count + 1);

  $file_type = wp_check_filetype($path, dlc_get_allowed_file_types());
  $mime_type = $file_type['type'] ? $file_type['type'] : 'application/octet-stream';

  nocache_headers();
  header('Content-Type: ' . $mime_type);
  header('Content-Disposition: attachment; filename="' . sanitize_file_name(basename($path)) . '"');
  header('Content-Length: ' . filesize($path));

  if (ob_get_length()) {
    ob_end_clean();
  }

  readfile($path);
  exit;
}
add_action('template_redirect', 'dlc_handle_download');

// Prints the right download control for the current visitor.
function dlc_render_download_button($post_id) {
  if (!get_post_meta($post_id, 'dlc_file_id', true)) {
    echo '<p class="dlc-note">No file has been attached to this resource yet.</p>';
    return;
  }

  if (current_user_can('dlc_use_library')) {
    printf('<a class="dlc-button" href="%s">Download file</a>', esc_url(dlc_get_download_url($post_id)));
    return;
  }

  if (is_user_logged_in()) {
    echo '<p class="dlc-note">Your account cannot download files.</p>';
    return;
  }

  $login_url = add_query_arg('redirect_to', rawurlencode(get_permalink($post_id)), dlc_get_page_url('login'));
  printf('<a class="dlc-button dlc-button-secondary" href="%s">Log in to download</a>', esc_url($login_url));
}

// Members and contributors manage everything from the front end, so they stay out of wp-admin.
function dlc_block_admin_for_members() {
  if (!is_user_logged_in() || wp_doing_ajax()) {
    return;
  }

  if (current_user_can('edit_dlc_resources') || current_user_can('manage_options')) {
    return;
  }

  wp_safe_redirect(home_url('/'));
  exit;
}
add_action('admin_init', 'dlc_block_admin_for_members');

function dlc_limit_admin_bar($show) {
  if (current_user_can('edit_dlc_resources') || current_user_can('manage_options')) {
    return $show;
  }
  return false;
}
add_filter('show_admin_bar', 'dlc_limit_admin_bar');
