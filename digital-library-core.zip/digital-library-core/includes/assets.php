<?php
/**
 * Loads the plugin's front-end stylesheet and the bookmark script.
 */

if (!defined('ABSPATH')) {
  exit;
}

function dlc_enqueue_assets() {
  wp_enqueue_style('dlc-library-core', DLC_URL . 'assets/css/library-core.css', array(), DLC_VERSION);

  if (!current_user_can('dlc_use_library')) {
    return;
  }

  wp_enqueue_script('dlc-bookmarks', DLC_URL . 'assets/js/bookmarks.js', array(), DLC_VERSION, true);
  wp_localize_script('dlc-bookmarks', 'dlcBookmarks', array(
    'ajaxUrl' => admin_url('admin-ajax.php'),
    'nonce' => wp_create_nonce('dlc-bookmark'),
  ));
}
add_action('wp_enqueue_scripts', 'dlc_enqueue_assets');
