<?php
/**
 * Bookmarks: each user keeps a list of saved resource IDs in user meta.
 */

if (!defined('ABSPATH')) {
  exit;
}

function dlc_get_bookmarks($user_id) {
  $bookmarks = get_user_meta($user_id, 'dlc_bookmarks', true);
  return is_array($bookmarks) ? array_map('absint', $bookmarks) : array();
}

function dlc_is_bookmarked($user_id, $post_id) {
  return in_array(absint($post_id), dlc_get_bookmarks($user_id), true);
}

function dlc_ajax_toggle_bookmark() {
  check_ajax_referer('dlc-bookmark', 'nonce');

  if (!current_user_can('dlc_use_library')) {
    wp_send_json_error(array('message' => 'Your account cannot bookmark resources.'), 403);
  }

  $post_id = isset($_POST['postId']) ? absint($_POST['postId']) : 0;
  if (!dlc_is_published_resource($post_id)) {
    wp_send_json_error(array('message' => 'Resource not found.'), 404);
  }

  $user_id = get_current_user_id();
  $bookmarks = dlc_get_bookmarks($user_id);
  $position = array_search($post_id, $bookmarks, true);

  if ($position === false) {
    $bookmarks[] = $post_id;
    $is_bookmarked = true;
  } else {
    unset($bookmarks[$position]);
    $is_bookmarked = false;
  }

  update_user_meta($user_id, 'dlc_bookmarks', array_values($bookmarks));
  wp_send_json_success(array('bookmarked' => $is_bookmarked));
}
add_action('wp_ajax_dlc_toggle_bookmark', 'dlc_ajax_toggle_bookmark');

// Visitors see no button; the button label stays fixed and aria-pressed carries the state.
function dlc_render_bookmark_button($post_id) {
  if (!current_user_can('dlc_use_library')) {
    return;
  }

  $is_bookmarked = dlc_is_bookmarked(get_current_user_id(), $post_id);
  printf(
    '<button type="button" class="dlc-bookmark-button" data-post-id="%d" aria-pressed="%s">Bookmark</button>',
    absint($post_id),
    $is_bookmarked ? 'true' : 'false'
  );
}
