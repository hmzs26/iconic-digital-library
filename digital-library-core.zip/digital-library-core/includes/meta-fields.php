<?php
/**
 * Resource details (authors, year, ISBN/DOI, file) and the admin meta box that edits them.
 */

if (!defined('ABSPATH')) {
  exit;
}

function dlc_get_meta_fields($post_type) {
  $fields = array(
    'dlc_authors' => array('label' => 'Author(s)', 'type' => 'text'),
    'dlc_year' => array('label' => 'Publication year', 'type' => 'number'),
  );

  if ($post_type === 'ebook') {
    $fields['dlc_isbn'] = array('label' => 'ISBN', 'type' => 'text');
  }

  if ($post_type === 'research-paper') {
    $fields['dlc_doi'] = array('label' => 'DOI', 'type' => 'text');
  }

  return $fields;
}

// Expects unslashed input.
function dlc_sanitize_meta_value($key, $value) {
  if ($key === 'dlc_year') {
    $year = absint($value);
    return $year > 0 ? (string) $year : '';
  }
  return sanitize_text_field($value);
}

// Expects unslashed input keyed by meta key.
function dlc_save_resource_meta($post_id, $post_type, $values) {
  foreach (array_keys(dlc_get_meta_fields($post_type)) as $key) {
    if (!isset($values[$key])) {
      continue;
    }
    update_post_meta($post_id, $key, dlc_sanitize_meta_value($key, $values[$key]));
  }
}

// Returns label => value pairs for the fields that have a value, ready to display.
function dlc_get_resource_details($post_id) {
  $details = array();
  foreach (dlc_get_meta_fields(get_post_type($post_id)) as $key => $field) {
    $value = get_post_meta($post_id, $key, true);
    if ($value !== '') {
      $details[$field['label']] = $value;
    }
  }
  return $details;
}

// Stores the uploaded file as an attachment and replaces any earlier file.
function dlc_attach_file_to_resource($post_id, $field_name) {
  $attachment_id = dlc_upload_resource_file($post_id, $field_name);
  if (is_wp_error($attachment_id)) {
    return $attachment_id;
  }

  $old_attachment_id = absint(get_post_meta($post_id, 'dlc_file_id', true));
  if ($old_attachment_id) {
    wp_delete_attachment($old_attachment_id, true);
  }

  update_post_meta($post_id, 'dlc_file_id', $attachment_id);
  return true;
}

function dlc_add_meta_box() {
  foreach (dlc_get_resource_post_types() as $post_type) {
    add_meta_box('dlc-resource-details', 'Resource details', 'dlc_render_meta_box', $post_type, 'normal', 'high');
  }
}
add_action('add_meta_boxes', 'dlc_add_meta_box');

function dlc_render_meta_box($post) {
  wp_nonce_field('dlc-save-resource', 'dlc-resource-nonce');
  echo '<table class="form-table" role="presentation">';

  foreach (dlc_get_meta_fields($post->post_type) as $key => $field) {
    $field_id = 'dlc-field-' . str_replace('_', '-', $key);
    printf(
      '<tr><th scope="row"><label for="%1$s">%2$s</label></th><td><input type="%3$s" id="%1$s" name="%4$s" value="%5$s" class="regular-text"></td></tr>',
      esc_attr($field_id),
      esc_html($field['label']),
      esc_attr($field['type']),
      esc_attr($key),
      esc_attr(get_post_meta($post->ID, $key, true))
    );
  }

  $current_file = get_attached_file(absint(get_post_meta($post->ID, 'dlc_file_id', true)));
  $current_label = $current_file ? basename($current_file) : 'No file attached yet';
  printf(
    '<tr><th scope="row"><label for="dlc-field-file">File (PDF or EPUB)</label></th><td><input type="file" id="dlc-field-file" name="resource-file" accept=".pdf,.epub"><p class="description">Current file: %s. Uploading a new file replaces it.</p></td></tr>',
    esc_html($current_label)
  );

  echo '</table>';
}

// The edit screen form must be multipart for the file input to work.
function dlc_add_form_enctype() {
  global $post;
  if ($post && in_array($post->post_type, dlc_get_resource_post_types(), true)) {
    echo ' enctype="multipart/form-data"';
  }
}
add_action('post_edit_form_tag', 'dlc_add_form_enctype');

function dlc_save_meta_box($post_id) {
  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
    return;
  }

  if (!isset($_POST['dlc-resource-nonce'])) {
    return;
  }

  $nonce = sanitize_text_field(wp_unslash($_POST['dlc-resource-nonce']));
  if (!wp_verify_nonce($nonce, 'dlc-save-resource')) {
    return;
  }

  if (!current_user_can('edit_post', $post_id)) {
    return;
  }

  $post_type = get_post_type($post_id);
  if (!in_array($post_type, dlc_get_resource_post_types(), true)) {
    return;
  }

  dlc_save_resource_meta($post_id, $post_type, wp_unslash($_POST));

  if (!empty($_FILES['resource-file']['name'])) {
    $result = dlc_attach_file_to_resource($post_id, 'resource-file');
    if (is_wp_error($result)) {
      set_transient('dlc_upload_error_' . get_current_user_id(), $result->get_error_message(), 60);
    }
  }
}
add_action('save_post', 'dlc_save_meta_box');

// Shows the upload error from the last save, because save_post cannot print output itself.
function dlc_show_upload_error_notice() {
  $transient_key = 'dlc_upload_error_' . get_current_user_id();
  $message = get_transient($transient_key);
  if (!$message) {
    return;
  }

  delete_transient($transient_key);
  printf('<div class="notice notice-error"><p>%s</p></div>', esc_html($message));
}
add_action('admin_notices', 'dlc_show_upload_error_notice');
