<?php
/**
 * Registers the ebook and research-paper post types and their taxonomies.
 */

if (!defined('ABSPATH')) {
  exit;
}

function dlc_get_resource_post_types() {
  return array('ebook', 'research-paper');
}

function dlc_is_published_resource($post_id) {
  $post = get_post($post_id);
  if (!$post) {
    return false;
  }
  return in_array($post->post_type, dlc_get_resource_post_types(), true) && $post->post_status === 'publish';
}

function dlc_register_post_types() {
  // Both types share one capability set, so one role covers the whole library.
  $shared_args = array(
    'public' => true,
    'has_archive' => true,
    // Classic editor on purpose: the file upload meta box needs a normal form submit.
    'show_in_rest' => false,
    'capability_type' => array('dlc_resource', 'dlc_resources'),
    'map_meta_cap' => true,
    'supports' => array('title', 'editor', 'excerpt', 'thumbnail'),
  );

  register_post_type('ebook', array_merge($shared_args, array(
    'labels' => array(
      'name' => 'Ebooks',
      'singular_name' => 'Ebook',
      'add_new_item' => 'Add new ebook',
      'edit_item' => 'Edit ebook',
    ),
    'menu_icon' => 'dashicons-book',
    'rewrite' => array('slug' => 'ebooks'),
  )));

  register_post_type('research-paper', array_merge($shared_args, array(
    'labels' => array(
      'name' => 'Research papers',
      'singular_name' => 'Research paper',
      'add_new_item' => 'Add new research paper',
      'edit_item' => 'Edit research paper',
    ),
    'menu_icon' => 'dashicons-media-document',
    'rewrite' => array('slug' => 'research-papers'),
  )));
}
add_action('init', 'dlc_register_post_types');

function dlc_register_taxonomies() {
  $post_types = dlc_get_resource_post_types();
  $capabilities = array(
    'manage_terms' => 'edit_others_dlc_resources',
    'edit_terms' => 'edit_others_dlc_resources',
    'delete_terms' => 'edit_others_dlc_resources',
    'assign_terms' => 'edit_dlc_resources',
  );

  // Subjects organise the collection; the public query var lets URLs filter by subject.
  register_taxonomy('dlc-subject', $post_types, array(
    'labels' => array('name' => 'Subjects', 'singular_name' => 'Subject'),
    'hierarchical' => true,
    'public' => true,
    'show_admin_column' => true,
    'capabilities' => $capabilities,
    'rewrite' => array('slug' => 'subject'),
  ));

  register_taxonomy('dlc-keyword', $post_types, array(
    'labels' => array('name' => 'Keywords', 'singular_name' => 'Keyword'),
    'hierarchical' => false,
    'public' => true,
    'capabilities' => $capabilities,
    'rewrite' => array('slug' => 'keyword'),
  ));
}
add_action('init', 'dlc_register_taxonomies');
