<?php
/**
 * Defines the library roles and the capabilities that control access.
 *
 * Visitor     - not logged in: can browse and search only.
 * Member      - can download files and keep bookmarks.
 * Contributor - Member, plus can submit resources for review.
 * Librarian   - Contributor, plus can edit, publish and delete all resources.
 */

if (!defined('ABSPATH')) {
  exit;
}

function dlc_get_resource_capabilities() {
  return array(
    'edit_dlc_resources',
    'edit_others_dlc_resources',
    'edit_published_dlc_resources',
    'edit_private_dlc_resources',
    'publish_dlc_resources',
    'read_private_dlc_resources',
    'delete_dlc_resources',
    'delete_others_dlc_resources',
    'delete_published_dlc_resources',
    'delete_private_dlc_resources',
  );
}

function dlc_add_roles() {
  $member_caps = array(
    'read' => true,
    'dlc_use_library' => true,
  );
  $contributor_caps = array_merge($member_caps, array(
    'dlc_submit_resources' => true,
  ));
  $librarian_caps = array_merge(
    $contributor_caps,
    array_fill_keys(dlc_get_resource_capabilities(), true),
    array('upload_files' => true)
  );

  // add_role does nothing if a role already exists, so existing roles keep their capabilities.
  add_role('dlc_member', 'Library Member', $member_caps);
  add_role('dlc_contributor', 'Library Contributor', $contributor_caps);
  add_role('dlc_librarian', 'Librarian', $librarian_caps);

  $administrator = get_role('administrator');
  if ($administrator) {
    foreach (array_keys($librarian_caps) as $capability) {
      $administrator->add_cap($capability);
    }
  }
}
