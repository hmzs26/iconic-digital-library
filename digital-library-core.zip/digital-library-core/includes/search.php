<?php
/**
 * Search: limits site search to library resources and adds type, subject, year and author filters.
 *
 * Filter URL parameters:
 *   s                 keyword (title and description)
 *   resource-type     ebook or research-paper
 *   dlc-subject       subject slug (WordPress applies this one itself through the taxonomy query var)
 *   resource-year     four-digit publication year
 *   resource-author   part of an author name
 *
 * The year and author parameters are prefixed because plain "year" and "author"
 * are reserved WordPress query variables.
 */

if (!defined('ABSPATH')) {
  exit;
}

function dlc_filter_search_query($query) {
  if (is_admin() || !$query->is_main_query() || !$query->is_search()) {
    return;
  }

  $post_types = dlc_get_resource_post_types();
  $requested_type = isset($_GET['resource-type']) ? sanitize_key(wp_unslash($_GET['resource-type'])) : '';
  if (in_array($requested_type, $post_types, true)) {
    $post_types = array($requested_type);
  }
  $query->set('post_type', $post_types);

  $meta_query = array();

  $year = isset($_GET['resource-year']) ? absint($_GET['resource-year']) : 0;
  if ($year > 0) {
    $meta_query[] = array(
      'key' => 'dlc_year',
      'value' => $year,
      'compare' => '=',
    );
  }

  $author = isset($_GET['resource-author']) ? sanitize_text_field(wp_unslash($_GET['resource-author'])) : '';
  if ($author !== '') {
    $meta_query[] = array(
      'key' => 'dlc_authors',
      'value' => $author,
      'compare' => 'LIKE',
    );
  }

  if ($meta_query) {
    $query->set('meta_query', $meta_query);
  }
}
add_action('pre_get_posts', 'dlc_filter_search_query');

// Builds a subject dropdown. Filters use slugs; the submit form uses term IDs.
function dlc_get_subject_select($name, $id, $selected, $use_slug, $blank_label) {
  $terms = get_terms(array('taxonomy' => 'dlc-subject', 'hide_empty' => false));

  $html = sprintf('<select id="%s" name="%s">', esc_attr($id), esc_attr($name));
  $html .= sprintf('<option value="">%s</option>', esc_html($blank_label));

  if (!is_wp_error($terms)) {
    foreach ($terms as $term) {
      $value = $use_slug ? $term->slug : (string) $term->term_id;
      $html .= sprintf(
        '<option value="%s"%s>%s</option>',
        esc_attr($value),
        selected((string) $selected, $value, false),
        esc_html($term->name)
      );
    }
  }

  return $html . '</select>';
}
