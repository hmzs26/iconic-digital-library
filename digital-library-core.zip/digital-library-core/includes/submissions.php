<?php
/**
 * Resource submission form for contributors. Submissions wait for librarian review.
 */

if (!defined('ABSPATH')) {
  exit;
}

function dlc_handle_submission() {
  if (!isset($_POST['dlc-submit-resource'])) {
    return;
  }

  if (!dlc_is_valid_nonce('dlc-submit-nonce', 'dlc-submit')) {
    dlc_form_errors(array('The security check failed. Reload the page and try again.'));
    return;
  }

  if (!current_user_can('dlc_submit_resources')) {
    dlc_form_errors(array('Your account is not allowed to submit resources.'));
    return;
  }

  $post_type = isset($_POST['resource-type']) ? sanitize_key(wp_unslash($_POST['resource-type'])) : '';
  $title = dlc_get_posted_value('title');
  $authors = dlc_get_posted_value('authors');
  $year = absint(wp_unslash(isset($_POST['year']) ? $_POST['year'] : 0));
  $identifier = dlc_get_posted_value('identifier');
  $subject_id = absint(wp_unslash(isset($_POST['subject']) ? $_POST['subject'] : 0));
  $description = wp_kses_post(wp_unslash(isset($_POST['description']) ? $_POST['description'] : ''));
  $file = isset($_FILES['resource-file']) ? $_FILES['resource-file'] : null;

  $errors = array();

  if (!in_array($post_type, dlc_get_resource_post_types(), true)) {
    $errors[] = 'Choose whether this is an ebook or a research paper.';
  }

  if ($title === '') {
    $errors[] = 'Enter a title.';
  }

  if ($authors === '') {
    $errors[] = 'Enter at least one author.';
  }

  $latest_year = (int) gmdate('Y') + 1;
  if ($year < 1000 || $year > $latest_year) {
    $errors[] = 'Enter a four-digit publication year.';
  }

  if (!$file || $file['error'] === UPLOAD_ERR_NO_FILE) {
    $errors[] = 'Attach a PDF or EPUB file.';
  } elseif ($file['error'] !== UPLOAD_ERR_OK) {
    $errors[] = 'The file could not be uploaded. Check its size and try again.';
  }

  if ($errors) {
    dlc_form_errors($errors);
    return;
  }

  $post_id = wp_insert_post(array(
    'post_type' => $post_type,
    'post_status' => 'pending',
    'post_title' => $title,
    'post_content' => $description,
    'post_author' => get_current_user_id(),
  ), true);

  if (is_wp_error($post_id)) {
    dlc_form_errors(array($post_id->get_error_message()));
    return;
  }

  // The identifier field means ISBN for ebooks and DOI for research papers.
  $identifier_key = $post_type === 'ebook' ? 'dlc_isbn' : 'dlc_doi';
  dlc_save_resource_meta($post_id, $post_type, array(
    'dlc_authors' => $authors,
    'dlc_year' => $year,
    $identifier_key => $identifier,
  ));

  if ($subject_id && term_exists($subject_id, 'dlc-subject')) {
    wp_set_object_terms($post_id, array($subject_id), 'dlc-subject');
  }

  $upload_result = dlc_attach_file_to_resource($post_id, 'resource-file');
  if (is_wp_error($upload_result)) {
    // Remove the half-created entry so the user can simply submit again.
    wp_delete_post($post_id, true);
    dlc_form_errors(array($upload_result->get_error_message()));
    return;
  }

  wp_safe_redirect(add_query_arg('submitted', '1', dlc_get_page_url('my-account')));
  exit;
}
add_action('template_redirect', 'dlc_handle_submission');

function dlc_render_submit_form() {
  if (!is_user_logged_in()) {
    return '<p class="dlc-note">Please <a href="' . esc_url(dlc_get_page_url('login')) . '">log in</a> to submit a resource.</p>';
  }

  if (!current_user_can('dlc_submit_resources')) {
    return '<p class="dlc-note">Only contributors can submit resources. Ask a librarian to upgrade your account.</p>';
  }

  $selected_type = dlc_get_posted_value('resource-type');

  ob_start();
  dlc_render_form_errors();
  ?>
  <form id="submit-form" class="dlc-form" method="post" enctype="multipart/form-data">
    <?php wp_nonce_field('dlc-submit', 'dlc-submit-nonce'); ?>
    <p>
      <label for="submit-type">Type</label>
      <select id="submit-type" name="resource-type" required>
        <option value="ebook"<?php selected($selected_type, 'ebook'); ?>>Ebook</option>
        <option value="research-paper"<?php selected($selected_type, 'research-paper'); ?>>Research paper</option>
      </select>
    </p>
    <p>
      <label for="submit-title">Title</label>
      <input type="text" id="submit-title" name="title" value="<?php echo esc_attr(dlc_get_posted_value('title')); ?>" required>
    </p>
    <p>
      <label for="submit-authors">Author(s)</label>
      <input type="text" id="submit-authors" name="authors" value="<?php echo esc_attr(dlc_get_posted_value('authors')); ?>" required>
    </p>
    <p>
      <label for="submit-year">Publication year</label>
      <input type="number" id="submit-year" name="year" min="1000" max="<?php echo esc_attr((int) gmdate('Y') + 1); ?>" value="<?php echo esc_attr(dlc_get_posted_value('year')); ?>" required>
    </p>
    <p>
      <label for="submit-identifier">ISBN (ebooks) or DOI (research papers), optional</label>
      <input type="text" id="submit-identifier" name="identifier" value="<?php echo esc_attr(dlc_get_posted_value('identifier')); ?>">
    </p>
    <p>
      <label for="submit-subject">Subject</label>
      <?php echo dlc_get_subject_select('subject', 'submit-subject', dlc_get_posted_value('subject'), false, 'No subject'); // phpcs:ignore WordPress.Security.EscapeOutput ?>
    </p>
    <p>
      <label for="submit-description">Description or abstract</label>
      <textarea id="submit-description" name="description" rows="6"><?php echo esc_textarea(isset($_POST['description']) ? wp_unslash($_POST['description']) : ''); ?></textarea>
    </p>
    <p>
      <label for="submit-file">File (PDF or EPUB)</label>
      <input type="file" id="submit-file" name="resource-file" accept=".pdf,.epub" required>
    </p>
    <button type="submit" name="dlc-submit-resource" class="dlc-button">Submit for review</button>
  </form>
  <?php
  return ob_get_clean();
}
add_shortcode('dlc_submit_resource', 'dlc_render_submit_form');
