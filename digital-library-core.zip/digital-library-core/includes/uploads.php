<?php
/**
 * Handles resource file uploads (PDF and EPUB only).
 */

if (!defined('ABSPATH')) {
  exit;
}

function dlc_get_allowed_file_types() {
  return array(
    'pdf' => 'application/pdf',
    'epub' => 'application/epub+zip',
  );
}

// Library files live in their own folder so they can be blocked from direct URL access.
function dlc_get_private_upload_dir($dirs) {
  $dirs['subdir'] = '/dlc-library';
  $dirs['path'] = $dirs['basedir'] . '/dlc-library';
  $dirs['url'] = $dirs['baseurl'] . '/dlc-library';
  return $dirs;
}

// Apache honours this file; nginx ignores it (see "Known limitations" in the README).
function dlc_protect_upload_dir() {
  $uploads = wp_upload_dir();
  $directory = $uploads['basedir'] . '/dlc-library';

  if (!is_dir($directory)) {
    wp_mkdir_p($directory);
  }

  $htaccess_path = $directory . '/.htaccess';
  if (!file_exists($htaccess_path)) {
    $rules = "<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n";
    $rules .= "<IfModule !mod_authz_core.c>\n  Deny from all\n</IfModule>\n";
    file_put_contents($htaccess_path, $rules);
  }

  $index_path = $directory . '/index.php';
  if (!file_exists($index_path)) {
    file_put_contents($index_path, "<?php\n// Silence is golden.\n");
  }
}

// Returns the new attachment ID, or a WP_Error describing the problem.
function dlc_upload_resource_file($post_id, $field_name) {
  require_once ABSPATH . 'wp-admin/includes/file.php';
  require_once ABSPATH . 'wp-admin/includes/media.php';
  require_once ABSPATH . 'wp-admin/includes/image.php';

  dlc_protect_upload_dir();

  add_filter('upload_dir', 'dlc_get_private_upload_dir');
  $attachment_id = media_handle_upload($field_name, $post_id, array(), array(
    'test_form' => false,
    'mimes' => dlc_get_allowed_file_types(),
  ));
  remove_filter('upload_dir', 'dlc_get_private_upload_dir');

  return $attachment_id;
}
