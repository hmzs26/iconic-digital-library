<?php
/**
 * Front-end account pages: registration, login and the member account page.
 * Each page is a shortcode, and the pages are created automatically on activation.
 */

if (!defined('ABSPATH')) {
  exit;
}

function dlc_get_page_url($slug) {
  $page = get_page_by_path($slug);
  if ($page) {
    return get_permalink($page);
  }
  return home_url('/' . $slug . '/');
}

function dlc_create_default_pages() {
  $pages = array(
    'login' => array('title' => 'Log in', 'content' => '[dlc_login]'),
    'register' => array('title' => 'Register', 'content' => '[dlc_register]'),
    'my-account' => array('title' => 'My account', 'content' => '[dlc_account]'),
    'submit-resource' => array('title' => 'Submit a resource', 'content' => '[dlc_submit_resource]'),
  );

  foreach ($pages as $slug => $page) {
    if (get_page_by_path($slug)) {
      continue;
    }

    wp_insert_post(array(
      'post_type' => 'page',
      'post_status' => 'publish',
      'post_name' => $slug,
      'post_title' => $page['title'],
      'post_content' => $page['content'],
    ));
  }
}

// Form handlers run before output starts, so they store errors here for the shortcode to print.
function dlc_form_errors($new_errors = null) {
  static $errors = array();
  if ($new_errors !== null) {
    $errors = $new_errors;
  }
  return $errors;
}

function dlc_render_form_errors() {
  $errors = dlc_form_errors();
  if (!$errors) {
    return;
  }

  echo '<div class="dlc-notice dlc-notice-error" role="alert"><ul>';
  foreach ($errors as $error) {
    echo '<li>' . esc_html($error) . '</li>';
  }
  echo '</ul></div>';
}

function dlc_is_valid_nonce($field_name, $action) {
  if (!isset($_POST[$field_name])) {
    return false;
  }
  return (bool) wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[$field_name])), $action);
}

// Refills a form after a failed submit. Never use it for passwords.
function dlc_get_posted_value($name) {
  return isset($_POST[$name]) ? sanitize_text_field(wp_unslash($_POST[$name])) : '';
}

function dlc_get_status_label($status) {
  $labels = array(
    'publish' => 'Published',
    'pending' => 'Waiting for librarian review',
    'draft' => 'Draft',
  );
  return isset($labels[$status]) ? $labels[$status] : $status;
}

/* Registration */

function dlc_handle_registration() {
  if (!isset($_POST['dlc-register-submit'])) {
    return;
  }

  if (!dlc_is_valid_nonce('dlc-register-nonce', 'dlc-register')) {
    dlc_form_errors(array('The security check failed. Reload the page and try again.'));
    return;
  }

  $username = sanitize_user(wp_unslash(isset($_POST['username']) ? $_POST['username'] : ''), true);
  $email = sanitize_email(wp_unslash(isset($_POST['email']) ? $_POST['email'] : ''));
  $display_name = dlc_get_posted_value('display-name');
  // Passwords are not sanitized, because that would silently change what the user typed.
  $password = wp_unslash(isset($_POST['password']) ? $_POST['password'] : '');

  $errors = array();

  if ($username === '') {
    $errors[] = 'Choose a username.';
  } elseif (username_exists($username)) {
    $errors[] = 'That username is taken. Choose another one.';
  }

  if (!is_email($email)) {
    $errors[] = 'Enter a valid email address.';
  } elseif (email_exists($email)) {
    $errors[] = 'An account with that email already exists. Try logging in.';
  }

  if (strlen($password) < 8) {
    $errors[] = 'The password must be at least 8 characters long.';
  }

  if ($errors) {
    dlc_form_errors($errors);
    return;
  }

  $user_id = wp_insert_user(array(
    'user_login' => $username,
    'user_email' => $email,
    'user_pass' => $password,
    'display_name' => $display_name !== '' ? $display_name : $username,
    'role' => 'dlc_member',
  ));

  if (is_wp_error($user_id)) {
    dlc_form_errors(array($user_id->get_error_message()));
    return;
  }

  wp_set_current_user($user_id);
  wp_set_auth_cookie($user_id);
  wp_safe_redirect(dlc_get_page_url('my-account'));
  exit;
}
add_action('template_redirect', 'dlc_handle_registration');

function dlc_render_register_form() {
  if (is_user_logged_in()) {
    return '<p class="dlc-note">You are already logged in. <a href="' . esc_url(dlc_get_page_url('my-account')) . '">Go to your account</a>.</p>';
  }

  ob_start();
  dlc_render_form_errors();
  ?>
  <form id="register-form" class="dlc-form" method="post">
    <?php wp_nonce_field('dlc-register', 'dlc-register-nonce'); ?>
    <p>
      <label for="register-username">Username</label>
      <input type="text" id="register-username" name="username" value="<?php echo esc_attr(dlc_get_posted_value('username')); ?>" autocomplete="username" required>
    </p>
    <p>
      <label for="register-display-name">Display name</label>
      <input type="text" id="register-display-name" name="display-name" value="<?php echo esc_attr(dlc_get_posted_value('display-name')); ?>" autocomplete="name">
    </p>
    <p>
      <label for="register-email">Email address</label>
      <input type="email" id="register-email" name="email" value="<?php echo esc_attr(dlc_get_posted_value('email')); ?>" autocomplete="email" required>
    </p>
    <p>
      <label for="register-password">Password (at least 8 characters)</label>
      <input type="password" id="register-password" name="password" minlength="8" autocomplete="new-password" required>
    </p>
    <button type="submit" name="dlc-register-submit" class="dlc-button">Create account</button>
  </form>
  <p class="dlc-note">Already registered? <a href="<?php echo esc_url(dlc_get_page_url('login')); ?>">Log in</a>.</p>
  <?php
  return ob_get_clean();
}
add_shortcode('dlc_register', 'dlc_render_register_form');

/* Login */

function dlc_get_login_redirect() {
  $target = isset($_GET['redirect_to']) ? esc_url_raw(wp_unslash($_GET['redirect_to'])) : '';
  return wp_validate_redirect($target, dlc_get_page_url('my-account'));
}

function dlc_render_login_form() {
  if (is_user_logged_in()) {
    return '<p class="dlc-note">You are already logged in. <a href="' . esc_url(dlc_get_page_url('my-account')) . '">Go to your account</a>.</p>';
  }

  $output = '';
  if (isset($_GET['login']) && $_GET['login'] === 'failed') {
    $output .= '<div class="dlc-notice dlc-notice-error" role="alert"><p>The username or password is not correct. Try again.</p></div>';
  }

  $output .= '<div class="dlc-form">';
  $output .= wp_login_form(array(
    'echo' => false,
    'redirect' => dlc_get_login_redirect(),
    'form_id' => 'login-form',
    'id_username' => 'login-username',
    'id_password' => 'login-password',
    'id_remember' => 'login-remember',
    'id_submit' => 'login-submit',
    'label_username' => 'Username or email',
    'label_log_in' => 'Log in',
  ));
  $output .= '</div>';
  $output .= '<p class="dlc-note">New here? <a href="' . esc_url(dlc_get_page_url('register')) . '">Create an account</a>.</p>';

  return $output;
}
add_shortcode('dlc_login', 'dlc_render_login_form');

// Sends failed logins back to the library login page instead of wp-login.php.
function dlc_redirect_failed_login() {
  $referrer = wp_get_referer();
  $login_url = dlc_get_page_url('login');

  if ($referrer && strpos($referrer, $login_url) === 0) {
    wp_safe_redirect(add_query_arg('login', 'failed', $login_url));
    exit;
  }
}
add_action('wp_login_failed', 'dlc_redirect_failed_login');

/* Account page */

function dlc_handle_profile_update() {
  if (!isset($_POST['dlc-profile-submit']) || !is_user_logged_in()) {
    return;
  }

  if (!dlc_is_valid_nonce('dlc-profile-nonce', 'dlc-profile')) {
    dlc_form_errors(array('The security check failed. Reload the page and try again.'));
    return;
  }

  $user_id = get_current_user_id();
  $display_name = dlc_get_posted_value('display-name');
  $email = sanitize_email(wp_unslash(isset($_POST['email']) ? $_POST['email'] : ''));

  $errors = array();

  if ($display_name === '') {
    $errors[] = 'Enter a display name.';
  }

  if (!is_email($email)) {
    $errors[] = 'Enter a valid email address.';
  } elseif (email_exists($email) && email_exists($email) !== $user_id) {
    $errors[] = 'Another account already uses that email address.';
  }

  if ($errors) {
    dlc_form_errors($errors);
    return;
  }

  wp_update_user(array(
    'ID' => $user_id,
    'display_name' => $display_name,
    'user_email' => $email,
  ));

  wp_safe_redirect(add_query_arg('updated', '1', dlc_get_page_url('my-account')));
  exit;
}
add_action('template_redirect', 'dlc_handle_profile_update');

// Lists resources with a link and a badge. Submission lists show a status instead of a bookmark button.
function dlc_render_resource_list($query_args, $empty_message, $show_status = false) {
  $query = new WP_Query($query_args);

  if (!$query->have_posts()) {
    echo '<p class="dlc-note">' . esc_html($empty_message) . '</p>';
    return;
  }

  echo '<ul class="dlc-list">';
  while ($query->have_posts()) {
    $query->the_post();
    $type_object = get_post_type_object(get_post_type());

    echo '<li class="dlc-list-item"><div class="dlc-list-text">';
    printf('<a href="%s">%s</a>', esc_url(get_permalink()), esc_html(get_the_title()));
    printf('<span class="dlc-badge">%s</span>', esc_html($type_object->labels->singular_name));
    if ($show_status) {
      printf('<span class="dlc-status">%s</span>', esc_html(dlc_get_status_label(get_post_status())));
    }
    echo '</div>';
    if (!$show_status) {
      dlc_render_bookmark_button(get_the_ID());
    }
    echo '</li>';
  }
  echo '</ul>';

  wp_reset_postdata();
}

function dlc_render_account_page() {
  if (!is_user_logged_in()) {
    return '<p class="dlc-note">Please <a href="' . esc_url(dlc_get_page_url('login')) . '">log in</a> to see your account.</p>';
  }

  $user = wp_get_current_user();
  $role_names = wp_roles()->get_names();
  $role_label = isset($user->roles[0], $role_names[$user->roles[0]]) ? $role_names[$user->roles[0]] : 'Member';

  ob_start();

  if (isset($_GET['updated'])) {
    echo '<div class="dlc-notice dlc-notice-success" role="status"><p>Your details were saved.</p></div>';
  }
  if (isset($_GET['submitted'])) {
    echo '<div class="dlc-notice dlc-notice-success" role="status"><p>Thank you. A librarian will review your submission before it is published.</p></div>';
  }
  dlc_render_form_errors();
  ?>
  <section class="dlc-section" aria-labelledby="account-details-heading">
    <h2 id="account-details-heading">Your details</h2>
    <p class="dlc-note">Account type: <?php echo esc_html($role_label); ?></p>
    <form id="profile-form" class="dlc-form" method="post">
      <?php wp_nonce_field('dlc-profile', 'dlc-profile-nonce'); ?>
      <p>
        <label for="profile-display-name">Display name</label>
        <input type="text" id="profile-display-name" name="display-name" value="<?php echo esc_attr($user->display_name); ?>" required>
      </p>
      <p>
        <label for="profile-email">Email address</label>
        <input type="email" id="profile-email" name="email" value="<?php echo esc_attr($user->user_email); ?>" required>
      </p>
      <button type="submit" name="dlc-profile-submit" class="dlc-button">Save details</button>
    </form>
  </section>

  <section class="dlc-section" aria-labelledby="account-bookmarks-heading">
    <h2 id="account-bookmarks-heading">Your bookmarks</h2>
    <?php
    $bookmark_ids = dlc_get_bookmarks($user->ID);
    dlc_render_resource_list(array(
      'post_type' => dlc_get_resource_post_types(),
      'post_status' => 'publish',
      'post__in' => $bookmark_ids ? $bookmark_ids : array(0),
      'orderby' => 'post__in',
      'posts_per_page' => -1,
    ), 'You have no bookmarks yet. Use the Bookmark button on any resource to save it here.');
    ?>
  </section>

  <?php if (current_user_can('dlc_submit_resources')) : ?>
    <section class="dlc-section" aria-labelledby="account-submissions-heading">
      <h2 id="account-submissions-heading">Your submissions</h2>
      <?php
      dlc_render_resource_list(array(
        'post_type' => dlc_get_resource_post_types(),
        'post_status' => array('publish', 'pending', 'draft'),
        'author' => $user->ID,
        'posts_per_page' => -1,
      ), 'You have not submitted anything yet.', true);
      ?>
      <p><a class="dlc-button" href="<?php echo esc_url(dlc_get_page_url('submit-resource')); ?>">Submit a resource</a></p>
    </section>
  <?php endif; ?>
  <?php
  return ob_get_clean();
}
add_shortcode('dlc_account', 'dlc_render_account_page');
