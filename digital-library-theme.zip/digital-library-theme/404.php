<?php get_header(); ?>

<div class="container page-content">
  <header class="page-header">
    <h1>Page not found</h1>
  </header>
  <p>That address does not match anything in the library. Try searching instead.</p>
  <?php get_search_form(); ?>
</div>

<?php get_footer(); ?>
