<?php
// Serves the ebook and research paper archives and the subject and keyword archives.
get_header();
?>

<div class="container page-content">
  <header class="page-header">
    <h1><?php the_archive_title(); ?></h1>
    <?php the_archive_description('<div class="page-description">', '</div>'); ?>
  </header>

  <?php if (have_posts()) : ?>
    <div class="resource-grid">
      <?php
      while (have_posts()) {
        the_post();
        get_template_part('template-parts/resource-card');
      }
      ?>
    </div>
    <?php the_posts_pagination(array('mid_size' => 1)); ?>
  <?php else : ?>
    <p>Nothing has been published here yet.</p>
  <?php endif; ?>
</div>

<?php get_footer(); ?>
