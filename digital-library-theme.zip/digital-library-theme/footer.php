</main>

<footer class="site-footer">
  <div class="container">
    <p><?php bloginfo('name'); ?> is a digital library and knowledge repository for learning resources.</p>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
