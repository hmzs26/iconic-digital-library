<?php get_header(); ?>

<section class="hero" aria-labelledby="hero-heading">
  <div class="container">
    <h1 id="hero-heading">Find the book or paper you need to study</h1>
    <p class="hero-text">Search the whole collection, or browse ebooks and research papers by subject.</p>

    <div class="hero-search">
      <?php get_template_part('template-parts/search-filters'); ?>
    </div>

    <p class="hero-counts">
      <?php
      $ebook_count = wp_count_posts('ebook');
      $paper_count = wp_count_posts('research-paper');
      printf(
        '%1$d ebooks and %2$d research papers in the collection',
        $ebook_count ? (int) $ebook_count->publish : 0,
        $paper_count ? (int) $paper_count->publish : 0
      );
      ?>
    </p>
  </div>
</section>

<?php
$sections = array(
  'ebook' => 'Latest ebooks',
  'research-paper' => 'Latest research papers',
);

foreach ($sections as $post_type => $section_title) :
  $latest = new WP_Query(array(
    'post_type' => $post_type,
    'posts_per_page' => 4,
    'post_status' => 'publish',
  ));
  $section_id = 'latest-' . $post_type;
  ?>
  <section class="resource-section container" aria-labelledby="<?php echo esc_attr($section_id); ?>">
    <div class="section-heading">
      <h2 id="<?php echo esc_attr($section_id); ?>"><?php echo esc_html($section_title); ?></h2>
      <?php if (get_post_type_archive_link($post_type)) : ?>
        <a href="<?php echo esc_url(get_post_type_archive_link($post_type)); ?>">See all</a>
      <?php endif; ?>
    </div>

    <?php if ($latest->have_posts()) : ?>
      <div class="resource-grid">
        <?php
        while ($latest->have_posts()) {
          $latest->the_post();
          get_template_part('template-parts/resource-card', null, array('heading' => 'h3'));
        }
        ?>
      </div>
    <?php else : ?>
      <p>Nothing has been published here yet.</p>
    <?php endif; ?>
  </section>
  <?php
  wp_reset_postdata();
endforeach;
?>

<?php get_footer(); ?>
