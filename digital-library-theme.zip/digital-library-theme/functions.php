<?php
/**
 * Theme setup and small helpers. Resource data and access rules live in the
 * Digital Library Core plugin, so every helper here falls back safely if it is inactive.
 */

if (!defined('ABSPATH')) {
  exit;
}

function dlt_setup_theme() {
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('html5', array('search-form', 'comment-list', 'comment-form', 'gallery', 'caption', 'style', 'script'));
}
add_action('after_setup_theme', 'dlt_setup_theme');

// Priority 20 loads the theme after the plugin stylesheet, so theme rules win ties.
function dlt_enqueue_assets() {
  $version = wp_get_theme()->get('Version');
  $theme_url = get_template_directory_uri();

  wp_enqueue_style('digital-library-theme', $theme_url . '/assets/css/main.css', array(), $version);
  wp_enqueue_script('digital-library-theme', $theme_url . '/assets/js/main.js', array(), $version, true);
}
add_action('wp_enqueue_scripts', 'dlt_enqueue_assets', 20);

function dlt_get_page_url($slug) {
  if (function_exists('dlc_get_page_url')) {
    return dlc_get_page_url($slug);
  }
  return home_url('/' . $slug . '/');
}

function dlt_get_resource_details($post_id) {
  return function_exists('dlc_get_resource_details') ? dlc_get_resource_details($post_id) : array();
}

function dlt_is_resource($post_id) {
  return in_array(get_post_type($post_id), array('ebook', 'research-paper'), true);
}

function dlt_aria_current($is_current) {
  return $is_current ? ' aria-current="page"' : '';
}

function dlt_get_type_label($post_type) {
  $type_object = get_post_type_object($post_type);
  return $type_object ? $type_object->labels->singular_name : '';
}
