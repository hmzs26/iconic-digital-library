<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main-content">Skip to main content</a>

<header class="site-header">
  <div class="site-header-inner container">
    <a class="site-title" href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a>

    <button id="menu-toggle" class="menu-toggle" type="button" aria-expanded="false" aria-controls="site-nav">Menu</button>

    <nav id="site-nav" class="site-nav" aria-label="Main">
      <ul class="site-nav-list">
        <li><a href="<?php echo esc_url(home_url('/')); ?>"<?php echo dlt_aria_current(is_front_page()); ?>>Home</a></li>
        <li><a href="<?php echo esc_url(get_post_type_archive_link('ebook')); ?>"<?php echo dlt_aria_current(is_post_type_archive('ebook')); ?>>Ebooks</a></li>
        <li><a href="<?php echo esc_url(get_post_type_archive_link('research-paper')); ?>"<?php echo dlt_aria_current(is_post_type_archive('research-paper')); ?>>Research papers</a></li>
      </ul>

      <div class="site-search">
        <?php get_search_form(); ?>
      </div>

      <ul class="site-nav-list site-nav-account">
        <?php if (is_user_logged_in()) : ?>
          <li><a href="<?php echo esc_url(dlt_get_page_url('my-account')); ?>">My account</a></li>
          <?php if (current_user_can('dlc_submit_resources')) : ?>
            <li><a href="<?php echo esc_url(dlt_get_page_url('submit-resource')); ?>">Submit</a></li>
          <?php endif; ?>
          <?php if (current_user_can('edit_dlc_resources')) : ?>
            <li><a href="<?php echo esc_url(admin_url()); ?>">Manage library</a></li>
          <?php endif; ?>
          <li><a href="<?php echo esc_url(wp_logout_url(home_url('/'))); ?>">Log out</a></li>
        <?php else : ?>
          <li><a href="<?php echo esc_url(dlt_get_page_url('login')); ?>">Log in</a></li>
          <li><a href="<?php echo esc_url(dlt_get_page_url('register')); ?>">Register</a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </div>
</header>

<main id="main-content" class="site-main">
