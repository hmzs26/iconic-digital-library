<?php
// Fallback template for anything the more specific templates do not cover.
get_header();
?>

<div class="container page-content">
  <?php if (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); ?>
      <article class="page-body">
        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
        <?php the_excerpt(); ?>
      </article>
    <?php endwhile; ?>
    <?php the_posts_pagination(); ?>
  <?php else : ?>
    <p>Nothing to show here yet.</p>
  <?php endif; ?>
</div>

<?php get_footer(); ?>
