<?php get_header(); ?>

<div class="container page-content">
  <?php while (have_posts()) : the_post(); ?>
    <article>
      <header class="page-header">
        <h1><?php the_title(); ?></h1>
      </header>
      <div class="page-body">
        <?php the_content(); ?>
      </div>
    </article>
  <?php endwhile; ?>
</div>

<?php get_footer(); ?>
