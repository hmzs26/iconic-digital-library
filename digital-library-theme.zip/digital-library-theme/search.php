<?php get_header(); ?>

<div class="container page-content">
  <header class="page-header">
    <h1>Search results</h1>
    <p class="page-description">
      <?php
      global $wp_query;
      printf('%d resources found', (int) $wp_query->found_posts);
      ?>
    </p>
  </header>

  <div class="search-panel">
    <?php get_template_part('template-parts/search-filters'); ?>
  </div>

  <?php if (have_posts()) : ?>
    <div class="resource-grid">
      <?php
      while (have_posts()) {
        the_post();
        get_template_part('template-parts/resource-card', null, array('heading' => 'h2'));
      }
      ?>
    </div>
    <?php the_posts_pagination(array('mid_size' => 1)); ?>
  <?php else : ?>
    <p>No resources match these filters. Try fewer filters or a shorter keyword.</p>
  <?php endif; ?>
</div>

<?php get_footer(); ?>
