<?php $search_id = wp_unique_id('search-'); ?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
  <label class="screen-reader-text" for="<?php echo esc_attr($search_id); ?>">Search the library</label>
  <input type="search" id="<?php echo esc_attr($search_id); ?>" name="s" value="<?php echo esc_attr(get_search_query()); ?>" placeholder="Search titles and descriptions">
  <button type="submit">Search</button>
</form>
