<?php get_header(); ?>

<div class="container page-content">
  <?php while (have_posts()) : the_post(); ?>
    <?php $is_resource = dlt_is_resource(get_the_ID()); ?>

    <article class="resource-detail">
      <header class="page-header">
        <?php if ($is_resource) : ?>
          <p class="resource-type resource-type-<?php echo esc_attr(get_post_type()); ?>"><?php echo esc_html(dlt_get_type_label(get_post_type())); ?></p>
        <?php endif; ?>
        <h1><?php the_title(); ?></h1>
      </header>

      <div class="resource-layout">
        <div class="resource-body">
          <?php the_content(); ?>
        </div>

        <?php if ($is_resource) : ?>
          <aside class="resource-sidebar" aria-labelledby="resource-details-heading">
            <?php if (has_post_thumbnail()) : ?>
              <div class="resource-cover"><?php the_post_thumbnail('medium'); ?></div>
            <?php endif; ?>

            <h2 id="resource-details-heading">Details</h2>
            <dl class="resource-details">
              <?php foreach (dlt_get_resource_details(get_the_ID()) as $label => $value) : ?>
                <dt><?php echo esc_html($label); ?></dt>
                <dd><?php echo esc_html($value); ?></dd>
              <?php endforeach; ?>

              <?php
              $subjects = get_the_term_list(get_the_ID(), 'dlc-subject', '', ', ');
              $keywords = get_the_term_list(get_the_ID(), 'dlc-keyword', '', ', ');
              ?>
              <?php if ($subjects && !is_wp_error($subjects)) : ?>
                <dt>Subject</dt>
                <dd><?php echo wp_kses_post($subjects); ?></dd>
              <?php endif; ?>
              <?php if ($keywords && !is_wp_error($keywords)) : ?>
                <dt>Keywords</dt>
                <dd><?php echo wp_kses_post($keywords); ?></dd>
              <?php endif; ?>
            </dl>

            <div class="resource-actions">
              <?php
              if (function_exists('dlc_render_download_button')) {
                dlc_render_download_button(get_the_ID());
              }
              if (function_exists('dlc_render_bookmark_button')) {
                dlc_render_bookmark_button(get_the_ID());
              }
              ?>
            </div>
          </aside>
        <?php endif; ?>
      </div>
    </article>
  <?php endwhile; ?>
</div>

<?php get_footer(); ?>
