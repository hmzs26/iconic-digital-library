<?php
/**
 * One resource in a list. Pass array('heading' => 'h3') as the third argument
 * of get_template_part() when the card sits under an h2 section heading.
 */

$heading_tag = isset($args['heading']) ? $args['heading'] : 'h2';
$post_type = get_post_type();
$authors = get_post_meta(get_the_ID(), 'dlc_authors', true);
$year = get_post_meta(get_the_ID(), 'dlc_year', true);
?>
<article class="resource-card">
  <p class="resource-type resource-type-<?php echo esc_attr($post_type); ?>"><?php echo esc_html(dlt_get_type_label($post_type)); ?></p>

  <<?php echo tag_escape($heading_tag); ?> class="resource-title">
    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
  </<?php echo tag_escape($heading_tag); ?>>

  <?php if ($authors) : ?>
    <p class="resource-authors"><?php echo esc_html($authors); ?><?php echo $year ? ', ' . esc_html($year) : ''; ?></p>
  <?php endif; ?>

  <p class="resource-excerpt"><?php echo esc_html(wp_trim_words(get_the_excerpt(), 24)); ?></p>

  <?php if (function_exists('dlc_render_bookmark_button')) : ?>
    <div class="resource-actions">
      <?php dlc_render_bookmark_button(get_the_ID()); ?>
    </div>
  <?php endif; ?>
</article>
