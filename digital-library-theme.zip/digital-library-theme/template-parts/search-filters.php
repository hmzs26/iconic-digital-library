<?php
// Reads the current filter values so the form stays filled after searching.
$selected_type = isset($_GET['resource-type']) ? sanitize_key(wp_unslash($_GET['resource-type'])) : '';
$selected_subject = isset($_GET['dlc-subject']) ? sanitize_title(wp_unslash($_GET['dlc-subject'])) : '';
$selected_year = isset($_GET['resource-year']) ? absint($_GET['resource-year']) : 0;
$selected_author = isset($_GET['resource-author']) ? sanitize_text_field(wp_unslash($_GET['resource-author'])) : '';
?>
<form id="filter-form" class="filter-form" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
  <div class="filter-field filter-field-wide">
    <label for="filter-keyword">Keyword</label>
    <input type="search" id="filter-keyword" name="s" value="<?php echo esc_attr(get_search_query()); ?>">
  </div>

  <div class="filter-field">
    <label for="filter-type">Type</label>
    <select id="filter-type" name="resource-type">
      <option value="">All types</option>
      <option value="ebook"<?php selected($selected_type, 'ebook'); ?>>Ebooks</option>
      <option value="research-paper"<?php selected($selected_type, 'research-paper'); ?>>Research papers</option>
    </select>
  </div>

  <?php if (function_exists('dlc_get_subject_select')) : ?>
    <div class="filter-field">
      <label for="filter-subject">Subject</label>
      <?php echo dlc_get_subject_select('dlc-subject', 'filter-subject', $selected_subject, true, 'All subjects'); // phpcs:ignore WordPress.Security.EscapeOutput ?>
    </div>
  <?php endif; ?>

  <div class="filter-field">
    <label for="filter-author">Author</label>
    <input type="text" id="filter-author" name="resource-author" value="<?php echo esc_attr($selected_author); ?>">
  </div>

  <div class="filter-field">
    <label for="filter-year">Year</label>
    <input type="number" id="filter-year" name="resource-year" min="1000" max="<?php echo esc_attr((int) gmdate('Y') + 1); ?>" value="<?php echo $selected_year ? esc_attr($selected_year) : ''; ?>">
  </div>

  <div class="filter-actions">
    <button type="submit">Search</button>
    <a href="<?php echo esc_url(home_url('/?s=')); ?>">Clear filters</a>
  </div>
</form>
